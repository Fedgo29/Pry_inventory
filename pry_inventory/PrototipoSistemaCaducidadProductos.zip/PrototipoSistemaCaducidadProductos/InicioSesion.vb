﻿Public Class InicioSesion

    Private Sub BotonCerrar_Click(sender As Object, e As EventArgs)
        Application.Exit()
    End Sub

    Private Sub BotonRestaurar_Click(sender As Object, e As EventArgs)
        WindowState = FormWindowState.Minimized
    End Sub

    Private Sub BotonInicio_Click(sender As Object, e As EventArgs) Handles BotonInicio.Click
        VentanaInicio.Show()
    End Sub


End Class