﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class VentanaInicio
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(VentanaInicio))
        PanelTitulo = New Panel()
        BotonRestaurar = New PictureBox()
        BotonMaximizar = New PictureBox()
        BotonMinimizar = New PictureBox()
        BotonCerrar = New PictureBox()
        PanelMenu = New Panel()
        Panel2 = New Panel()
        BotonSalir = New Button()
        Panel1 = New Panel()
        BotonInicio = New Button()
        PanelContenedor = New Panel()
        DataGridView1 = New DataGridView()
        GroupBoxProducto = New GroupBox()
        TextBox9 = New TextBox()
        Label8 = New Label()
        TextBox10 = New TextBox()
        Label9 = New Label()
        TextBox11 = New TextBox()
        Label10 = New Label()
        TextBox12 = New TextBox()
        Label11 = New Label()
        TextBox5 = New TextBox()
        Label4 = New Label()
        TextBox6 = New TextBox()
        Label5 = New Label()
        TextBox7 = New TextBox()
        Label6 = New Label()
        TextBox8 = New TextBox()
        Label7 = New Label()
        TextBox4 = New TextBox()
        Label3 = New Label()
        TextBox3 = New TextBox()
        Label2 = New Label()
        TextBox2 = New TextBox()
        Label1 = New Label()
        TextBox1 = New TextBox()
        LabelCodigodeBarra = New Label()
        PanelTitulo.SuspendLayout()
        CType(BotonRestaurar, ComponentModel.ISupportInitialize).BeginInit()
        CType(BotonMaximizar, ComponentModel.ISupportInitialize).BeginInit()
        CType(BotonMinimizar, ComponentModel.ISupportInitialize).BeginInit()
        CType(BotonCerrar, ComponentModel.ISupportInitialize).BeginInit()
        PanelMenu.SuspendLayout()
        PanelContenedor.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        GroupBoxProducto.SuspendLayout()
        SuspendLayout()
        ' 
        ' PanelTitulo
        ' 
        PanelTitulo.BackColor = Color.DarkCyan
        PanelTitulo.Controls.Add(BotonRestaurar)
        PanelTitulo.Controls.Add(BotonMaximizar)
        PanelTitulo.Controls.Add(BotonMinimizar)
        PanelTitulo.Controls.Add(BotonCerrar)
        PanelTitulo.Dock = DockStyle.Top
        PanelTitulo.Location = New Point(0, 0)
        PanelTitulo.Name = "PanelTitulo"
        PanelTitulo.Size = New Size(1300, 40)
        PanelTitulo.TabIndex = 0
        ' 
        ' BotonRestaurar
        ' 
        BotonRestaurar.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        BotonRestaurar.Image = CType(resources.GetObject("BotonRestaurar.Image"), Image)
        BotonRestaurar.Location = New Point(1216, 6)
        BotonRestaurar.Name = "BotonRestaurar"
        BotonRestaurar.Size = New Size(28, 28)
        BotonRestaurar.SizeMode = PictureBoxSizeMode.Zoom
        BotonRestaurar.TabIndex = 3
        BotonRestaurar.TabStop = False
        BotonRestaurar.Visible = False
        ' 
        ' BotonMaximizar
        ' 
        BotonMaximizar.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        BotonMaximizar.Image = CType(resources.GetObject("BotonMaximizar.Image"), Image)
        BotonMaximizar.Location = New Point(1216, 6)
        BotonMaximizar.Name = "BotonMaximizar"
        BotonMaximizar.Size = New Size(28, 28)
        BotonMaximizar.SizeMode = PictureBoxSizeMode.Zoom
        BotonMaximizar.TabIndex = 2
        BotonMaximizar.TabStop = False
        ' 
        ' BotonMinimizar
        ' 
        BotonMinimizar.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        BotonMinimizar.Image = CType(resources.GetObject("BotonMinimizar.Image"), Image)
        BotonMinimizar.Location = New Point(1172, 6)
        BotonMinimizar.Name = "BotonMinimizar"
        BotonMinimizar.Size = New Size(28, 28)
        BotonMinimizar.SizeMode = PictureBoxSizeMode.Zoom
        BotonMinimizar.TabIndex = 1
        BotonMinimizar.TabStop = False
        ' 
        ' BotonCerrar
        ' 
        BotonCerrar.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        BotonCerrar.Image = CType(resources.GetObject("BotonCerrar.Image"), Image)
        BotonCerrar.Location = New Point(1260, 6)
        BotonCerrar.Name = "BotonCerrar"
        BotonCerrar.Size = New Size(28, 28)
        BotonCerrar.SizeMode = PictureBoxSizeMode.Zoom
        BotonCerrar.TabIndex = 0
        BotonCerrar.TabStop = False
        ' 
        ' PanelMenu
        ' 
        PanelMenu.BackColor = Color.FromArgb(CByte(0), CByte(64), CByte(64))
        PanelMenu.Controls.Add(Panel2)
        PanelMenu.Controls.Add(BotonSalir)
        PanelMenu.Controls.Add(Panel1)
        PanelMenu.Controls.Add(BotonInicio)
        PanelMenu.Dock = DockStyle.Left
        PanelMenu.Location = New Point(0, 40)
        PanelMenu.Name = "PanelMenu"
        PanelMenu.Size = New Size(232, 610)
        PanelMenu.TabIndex = 1
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.DarkCyan
        Panel2.Location = New Point(0, 385)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(11, 54)
        Panel2.TabIndex = 2
        ' 
        ' BotonSalir
        ' 
        BotonSalir.FlatAppearance.BorderSize = 0
        BotonSalir.FlatAppearance.MouseOverBackColor = Color.DarkCyan
        BotonSalir.FlatStyle = FlatStyle.Flat
        BotonSalir.Font = New Font("Bahnschrift SemiCondensed", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        BotonSalir.ForeColor = Color.White
        BotonSalir.Location = New Point(0, 385)
        BotonSalir.Name = "BotonSalir"
        BotonSalir.Size = New Size(232, 54)
        BotonSalir.TabIndex = 2
        BotonSalir.Text = "SALIR"
        BotonSalir.UseVisualStyleBackColor = True
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.DarkCyan
        Panel1.Location = New Point(0, 114)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(11, 54)
        Panel1.TabIndex = 1
        ' 
        ' BotonInicio
        ' 
        BotonInicio.FlatAppearance.BorderSize = 0
        BotonInicio.FlatAppearance.MouseOverBackColor = Color.DarkCyan
        BotonInicio.FlatStyle = FlatStyle.Flat
        BotonInicio.Font = New Font("Bahnschrift SemiCondensed", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        BotonInicio.ForeColor = Color.White
        BotonInicio.Location = New Point(0, 114)
        BotonInicio.Name = "BotonInicio"
        BotonInicio.Size = New Size(232, 54)
        BotonInicio.TabIndex = 0
        BotonInicio.Text = "INICIO"
        BotonInicio.UseVisualStyleBackColor = True
        ' 
        ' PanelContenedor
        ' 
        PanelContenedor.BackColor = Color.White
        PanelContenedor.Controls.Add(DataGridView1)
        PanelContenedor.Controls.Add(GroupBoxProducto)
        PanelContenedor.Dock = DockStyle.Fill
        PanelContenedor.Location = New Point(232, 40)
        PanelContenedor.Name = "PanelContenedor"
        PanelContenedor.Size = New Size(1068, 610)
        PanelContenedor.TabIndex = 2
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(474, 74)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowHeadersWidth = 51
        DataGridView1.Size = New Size(553, 472)
        DataGridView1.TabIndex = 1
        ' 
        ' GroupBoxProducto
        ' 
        GroupBoxProducto.Controls.Add(TextBox9)
        GroupBoxProducto.Controls.Add(Label8)
        GroupBoxProducto.Controls.Add(TextBox10)
        GroupBoxProducto.Controls.Add(Label9)
        GroupBoxProducto.Controls.Add(TextBox11)
        GroupBoxProducto.Controls.Add(Label10)
        GroupBoxProducto.Controls.Add(TextBox12)
        GroupBoxProducto.Controls.Add(Label11)
        GroupBoxProducto.Controls.Add(TextBox5)
        GroupBoxProducto.Controls.Add(Label4)
        GroupBoxProducto.Controls.Add(TextBox6)
        GroupBoxProducto.Controls.Add(Label5)
        GroupBoxProducto.Controls.Add(TextBox7)
        GroupBoxProducto.Controls.Add(Label6)
        GroupBoxProducto.Controls.Add(TextBox8)
        GroupBoxProducto.Controls.Add(Label7)
        GroupBoxProducto.Controls.Add(TextBox4)
        GroupBoxProducto.Controls.Add(Label3)
        GroupBoxProducto.Controls.Add(TextBox3)
        GroupBoxProducto.Controls.Add(Label2)
        GroupBoxProducto.Controls.Add(TextBox2)
        GroupBoxProducto.Controls.Add(Label1)
        GroupBoxProducto.Controls.Add(TextBox1)
        GroupBoxProducto.Controls.Add(LabelCodigodeBarra)
        GroupBoxProducto.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        GroupBoxProducto.ForeColor = Color.Black
        GroupBoxProducto.Location = New Point(44, 52)
        GroupBoxProducto.Name = "GroupBoxProducto"
        GroupBoxProducto.Size = New Size(408, 506)
        GroupBoxProducto.TabIndex = 0
        GroupBoxProducto.TabStop = False
        GroupBoxProducto.Text = "Producto"
        ' 
        ' TextBox9
        ' 
        TextBox9.Location = New Point(188, 373)
        TextBox9.Name = "TextBox9"
        TextBox9.Size = New Size(205, 30)
        TextBox9.TabIndex = 23
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label8.ForeColor = Color.Black
        Label8.Location = New Point(112, 380)
        Label8.Name = "Label8"
        Label8.Size = New Size(70, 20)
        Label8.TabIndex = 22
        Label8.Text = "Utilidad:"
        ' 
        ' TextBox10
        ' 
        TextBox10.Location = New Point(188, 445)
        TextBox10.Name = "TextBox10"
        TextBox10.Size = New Size(205, 30)
        TextBox10.TabIndex = 21
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label9.ForeColor = Color.Black
        Label9.Location = New Point(15, 452)
        Label9.Name = "Label9"
        Label9.Size = New Size(167, 20)
        Label9.TabIndex = 20
        Label9.Text = "Fecha de Caducidad:"
        ' 
        ' TextBox11
        ' 
        TextBox11.Location = New Point(188, 409)
        TextBox11.Name = "TextBox11"
        TextBox11.Size = New Size(205, 30)
        TextBox11.TabIndex = 19
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label10.ForeColor = Color.Black
        Label10.Location = New Point(25, 416)
        Label10.Name = "Label10"
        Label10.Size = New Size(157, 20)
        Label10.TabIndex = 18
        Label10.Text = "Cantidad Inventario:"
        ' 
        ' TextBox12
        ' 
        TextBox12.Location = New Point(188, 337)
        TextBox12.Name = "TextBox12"
        TextBox12.Size = New Size(205, 30)
        TextBox12.TabIndex = 17
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label11.ForeColor = Color.Black
        Label11.Location = New Point(49, 344)
        Label11.Name = "Label11"
        Label11.Size = New Size(133, 20)
        Label11.TabIndex = 16
        Label11.Text = "Precio de Venta:"
        ' 
        ' TextBox5
        ' 
        TextBox5.Location = New Point(188, 229)
        TextBox5.Name = "TextBox5"
        TextBox5.Size = New Size(205, 30)
        TextBox5.TabIndex = 15
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.ForeColor = Color.Black
        Label4.Location = New Point(121, 236)
        Label4.Name = "Label4"
        Label4.Size = New Size(61, 20)
        Label4.TabIndex = 14
        Label4.Text = "Marca:"
        ' 
        ' TextBox6
        ' 
        TextBox6.Location = New Point(188, 301)
        TextBox6.Name = "TextBox6"
        TextBox6.Size = New Size(205, 30)
        TextBox6.TabIndex = 13
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label5.ForeColor = Color.Black
        Label5.Location = New Point(33, 308)
        Label5.Name = "Label5"
        Label5.Size = New Size(149, 20)
        Label5.TabIndex = 12
        Label5.Text = "Precio de Compra:"
        ' 
        ' TextBox7
        ' 
        TextBox7.Location = New Point(188, 265)
        TextBox7.Name = "TextBox7"
        TextBox7.Size = New Size(205, 30)
        TextBox7.TabIndex = 11
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label6.ForeColor = Color.Black
        Label6.Location = New Point(92, 272)
        Label6.Name = "Label6"
        Label6.Size = New Size(90, 20)
        Label6.TabIndex = 10
        Label6.Text = "Proveedor:"
        ' 
        ' TextBox8
        ' 
        TextBox8.Location = New Point(188, 193)
        TextBox8.Name = "TextBox8"
        TextBox8.Size = New Size(205, 30)
        TextBox8.TabIndex = 9
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label7.ForeColor = Color.Black
        Label7.Location = New Point(96, 200)
        Label7.Name = "Label7"
        Label7.Size = New Size(86, 20)
        Label7.TabIndex = 8
        Label7.Text = "Categoría:"
        ' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(188, 85)
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(205, 30)
        TextBox4.TabIndex = 7
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = Color.Black
        Label3.Location = New Point(46, 92)
        Label3.Name = "Label3"
        Label3.Size = New Size(136, 20)
        Label3.TabIndex = 6
        Label3.Text = "Código de Barra:"
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(188, 157)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(205, 30)
        TextBox3.TabIndex = 5
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = Color.Black
        Label2.Location = New Point(142, 164)
        Label2.Name = "Label2"
        Label2.Size = New Size(40, 20)
        Label2.TabIndex = 4
        Label2.Text = "UM:"
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(188, 121)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(205, 30)
        TextBox2.TabIndex = 3
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.Black
        Label1.Location = New Point(108, 128)
        Label1.Name = "Label1"
        Label1.Size = New Size(74, 20)
        Label1.TabIndex = 2
        Label1.Text = "Material:"
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(188, 49)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(205, 30)
        TextBox1.TabIndex = 1
        ' 
        ' LabelCodigodeBarra
        ' 
        LabelCodigodeBarra.AutoSize = True
        LabelCodigodeBarra.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        LabelCodigodeBarra.ForeColor = Color.Black
        LabelCodigodeBarra.Location = New Point(78, 56)
        LabelCodigodeBarra.Name = "LabelCodigodeBarra"
        LabelCodigodeBarra.Size = New Size(104, 20)
        LabelCodigodeBarra.TabIndex = 0
        LabelCodigodeBarra.Text = "Descripción:"
        ' 
        ' VentanaInicio
        ' 
        AutoScaleDimensions = New SizeF(120F, 120F)
        AutoScaleMode = AutoScaleMode.Dpi
        ClientSize = New Size(1300, 650)
        Controls.Add(PanelContenedor)
        Controls.Add(PanelMenu)
        Controls.Add(PanelTitulo)
        FormBorderStyle = FormBorderStyle.None
        Name = "VentanaInicio"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Form1"
        PanelTitulo.ResumeLayout(False)
        CType(BotonRestaurar, ComponentModel.ISupportInitialize).EndInit()
        CType(BotonMaximizar, ComponentModel.ISupportInitialize).EndInit()
        CType(BotonMinimizar, ComponentModel.ISupportInitialize).EndInit()
        CType(BotonCerrar, ComponentModel.ISupportInitialize).EndInit()
        PanelMenu.ResumeLayout(False)
        PanelContenedor.ResumeLayout(False)
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        GroupBoxProducto.ResumeLayout(False)
        GroupBoxProducto.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents PanelTitulo As Panel
    Friend WithEvents PanelMenu As Panel
    Friend WithEvents PanelContenedor As Panel
    Friend WithEvents BotonCerrar As PictureBox
    Friend WithEvents BotonMaximizar As PictureBox
    Friend WithEvents BotonMinimizar As PictureBox
    Friend WithEvents BotonRestaurar As PictureBox
    Friend WithEvents BotonInicio As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents BotonSalir As Button
    Friend WithEvents GroupBoxProducto As GroupBox
    Friend WithEvents LabelCodigodeBarra As Label
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents DataGridView1 As DataGridView

End Class
